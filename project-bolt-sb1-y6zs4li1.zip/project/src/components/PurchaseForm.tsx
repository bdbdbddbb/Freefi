import React, { useState } from 'react';
import { Account } from '../types';

interface PurchaseFormProps {
  account: Account;
  onSubmit: (whatsappNumber: string, rechargeCode: string) => void;
}

export function PurchaseForm({ account, onSubmit }: PurchaseFormProps) {
  const [whatsappNumber, setWhatsappNumber] = useState('');
  const [rechargeCode, setRechargeCode] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(whatsappNumber, rechargeCode);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white p-8 rounded-lg shadow-lg w-full max-w-md">
        <h2 className="text-2xl font-bold text-center mb-6">إتمام الشراء</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">
              رمز شحن {account.paymentMethod === 'inwi' ? 'إنوي' : 'أورنج'}
            </label>
            <input
              type="text"
              value={rechargeCode}
              onChange={(e) => setRechargeCode(e.target.value)}
              className="w-full px-4 py-2 border rounded-lg text-right"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">رقم الواتساب</label>
            <input
              type="tel"
              value={whatsappNumber}
              onChange={(e) => setWhatsappNumber(e.target.value)}
              className="w-full px-4 py-2 border rounded-lg text-right"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700"
          >
            تأكيد
          </button>
        </form>
      </div>
    </div>
  );
}