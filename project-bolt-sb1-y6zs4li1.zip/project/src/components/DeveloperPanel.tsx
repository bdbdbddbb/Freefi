import React, { useState } from 'react';
import { Account, Purchase } from '../types';

interface DeveloperPanelProps {
  accounts: Account[];
  purchases: Purchase[];
  onAddAccount: (account: Omit<Account, 'id'>) => void;
}

export function DeveloperPanel({ accounts, purchases, onAddAccount }: DeveloperPanelProps) {
  const [videoUrl, setVideoUrl] = useState('');
  const [price, setPrice] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'inwi' | 'orange'>('inwi');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddAccount({
      videoUrl,
      price: Number(price),
      paymentMethod,
    });
    setVideoUrl('');
    setPrice('');
  };

  return (
    <div className="p-6">
      <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
        <h2 className="text-2xl font-bold mb-4">إضافة حساب جديد</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">رابط فيديو يوتيوب</label>
            <input
              type="url"
              value={videoUrl}
              onChange={(e) => setVideoUrl(e.target.value)}
              className="w-full px-4 py-2 border rounded-lg text-right"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">السعر (درهم)</label>
            <input
              type="number"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              className="w-full px-4 py-2 border rounded-lg text-right"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">طريقة الدفع</label>
            <select
              value={paymentMethod}
              onChange={(e) => setPaymentMethod(e.target.value as 'inwi' | 'orange')}
              className="w-full px-4 py-2 border rounded-lg text-right"
            >
              <option value="inwi">إنوي</option>
              <option value="orange">أورنج</option>
            </select>
          </div>
          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700"
          >
            إضافة حساب
          </button>
        </form>
      </div>

      <div className="bg-white rounded-lg shadow-lg p-6">
        <h2 className="text-2xl font-bold mb-4">سجل المشتريات</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-right py-2">واتساب</th>
                <th className="text-right py-2">رمز الشحن</th>
                <th className="text-right py-2">الحالة</th>
                <th className="text-right py-2">التاريخ</th>
              </tr>
            </thead>
            <tbody>
              {purchases.map((purchase) => (
                <tr key={purchase.id} className="border-b">
                  <td className="py-2">{purchase.whatsappNumber}</td>
                  <td className="py-2">{purchase.rechargeCode}</td>
                  <td className="py-2">{
                    purchase.status === 'pending' ? 'قيد الانتظار' :
                    purchase.status === 'completed' ? 'مكتمل' : 'مرفوض'
                  }</td>
                  <td className="py-2">
                    {new Date(purchase.timestamp).toLocaleDateString('ar-MA')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}