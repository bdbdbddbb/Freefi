import React from 'react';
import { Account } from '../types';

interface AccountsListProps {
  accounts: Account[];
  onPurchase: (account: Account) => void;
}

export function AccountsList({ accounts, onPurchase }: AccountsListProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
      {accounts.map((account) => (
        <div key={account.id} className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="aspect-video">
            <iframe
              width="100%"
              height="100%"
              src={`https://www.youtube.com/embed/${account.videoUrl.split('v=')[1]}`}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            ></iframe>
          </div>
          <div className="p-4">
            <div className="flex justify-between items-center mb-4">
              <span className="text-xl font-bold">{account.price} درهم</span>
              <span className="text-sm text-gray-600">
                {account.paymentMethod === 'inwi' ? 'إنوي' : 'أورنج'}
              </span>
            </div>
            <button
              onClick={() => onPurchase(account)}
              className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700"
            >
              شراء الآن
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}