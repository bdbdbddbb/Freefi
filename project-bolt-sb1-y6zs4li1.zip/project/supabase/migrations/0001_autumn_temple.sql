/*
  # Initial Schema Setup for Free Fire Marketplace

  1. New Tables
    - `accounts`
      - `id` (uuid, primary key)
      - `video_url` (text)
      - `price` (integer)
      - `payment_method` (text)
      - `created_at` (timestamp)
    
    - `purchases`
      - `id` (uuid, primary key)
      - `account_id` (uuid, foreign key)
      - `whatsapp_number` (text)
      - `recharge_code` (text)
      - `status` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users
*/

-- Create accounts table
CREATE TABLE accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  video_url text NOT NULL,
  price integer NOT NULL,
  payment_method text NOT NULL CHECK (payment_method IN ('inwi', 'orange')),
  created_at timestamptz DEFAULT now()
);

-- Create purchases table
CREATE TABLE purchases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id uuid REFERENCES accounts(id),
  whatsapp_number text NOT NULL,
  recharge_code text NOT NULL,
  status text NOT NULL CHECK (status IN ('pending', 'completed', 'rejected')),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchases ENABLE ROW LEVEL SECURITY;

-- Policies for accounts
CREATE POLICY "Anyone can view accounts"
  ON accounts
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Developers can manage accounts"
  ON accounts
  FOR ALL
  TO authenticated
  USING (auth.uid() IN (
    SELECT auth.uid() 
    FROM auth.users 
    WHERE email = 'developer@example.com'
  ));

-- Policies for purchases
CREATE POLICY "Users can view their own purchases"
  ON purchases
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can create purchases"
  ON purchases
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Developers can manage purchases"
  ON purchases
  FOR ALL
  TO authenticated
  USING (auth.uid() IN (
    SELECT auth.uid() 
    FROM auth.users 
    WHERE email = 'developer@example.com'
  ));