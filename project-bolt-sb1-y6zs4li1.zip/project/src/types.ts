export interface Account {
  id: string;
  videoUrl: string;
  price: number;
  paymentMethod: 'inwi' | 'orange';
}

export interface Purchase {
  id: string;
  accountId: string;
  whatsappNumber: string;
  rechargeCode: string;
  timestamp: Date;
  status: 'pending' | 'completed' | 'rejected';
}